/**
 * ==========================================================================
 * ALBERTO CLOCKS — COMMON JAVASCRIPT (js/common.js)
 * Shared across all pages:
 *   1. Visitor Counter (localStorage)
 *   2. Active Navigation Highlighter
 *   3. Mobile Navigation Drawer Toggle
 *   4. Live Date, Time & HTML5 Geolocation Ticker
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  initVisitorCounter();
  initActiveNav();
  initMobileNav();
  initBottomTicker();
});

/* --------------------------------------------------------------------------
   1. VISITOR COUNTER USING LOCALSTORAGE
   -------------------------------------------------------------------------- */
function initVisitorCounter() {
  const visitorElement = document.getElementById('visitorCount');
  if (!visitorElement) return;

  const STORAGE_KEY = 'alberto_clocks_visitors';
  const BASE_VISITOR_COUNT = 124;

  let currentCount = localStorage.getItem(STORAGE_KEY);

  if (currentCount === null || isNaN(parseInt(currentCount))) {
    currentCount = BASE_VISITOR_COUNT + 1;
  } else {
    currentCount = parseInt(currentCount) + 1;
  }

  localStorage.setItem(STORAGE_KEY, currentCount);
  visitorElement.textContent = `Visitors: ${currentCount}`;
}

/* --------------------------------------------------------------------------
   2. ACTIVE NAVIGATION HIGHLIGHTER
   -------------------------------------------------------------------------- */
function initActiveNav() {
  const navLinks = document.querySelectorAll('.nav-link');
  let currentPath = window.location.pathname;
  let currentPage = currentPath.substring(currentPath.lastIndexOf('/') + 1);

  if (!currentPage || currentPage === '') {
    currentPage = 'index.html';
  }

  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

/* --------------------------------------------------------------------------
   3. MOBILE NAVIGATION DRAWER TOGGLE
   -------------------------------------------------------------------------- */
function initMobileNav() {
  const toggleBtn = document.getElementById('mobileNavBtn');
  const navList = document.getElementById('mainNavList');

  if (toggleBtn && navList) {
    toggleBtn.addEventListener('click', () => {
      navList.classList.toggle('mobile-open');
      const isExpanded = navList.classList.contains('mobile-open');
      toggleBtn.innerHTML = isExpanded ? '&#10005;' : '&#9776;';
    });
  }
}

/* --------------------------------------------------------------------------
   4. LIVE DATE, TIME & HTML5 GEOLOCATION TICKER
   -------------------------------------------------------------------------- */
let userLocationText = 'Detecting location...';

function initBottomTicker() {
  detectUserLocation();
  updateTickerDateTime();
  setInterval(updateTickerDateTime, 1000);
}

function detectUserLocation() {
  if ('geolocation' in navigator) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude.toFixed(2);
        const lon = position.coords.longitude.toFixed(2);
        userLocationText = `Verified GPS (${lat}°, ${lon}°) | Karachi Regional Time`;
        updateTickerDateTime();
      },
      (error) => {
        userLocationText = 'Location unavailable';
        updateTickerDateTime();
      },
      { timeout: 8000, enableHighAccuracy: false }
    );
  } else {
    userLocationText = 'Location unavailable';
    updateTickerDateTime();
  }
}

function updateTickerDateTime() {
  const now = new Date();

  const dateOptions = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };
  const dateString = now.toLocaleDateString('en-US', dateOptions);

  const timeString = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  const tickerElements = document.querySelectorAll('.ticker-data');
  tickerElements.forEach(el => {
    el.innerHTML = `Date: <strong>${dateString}</strong> <span class="ticker-divider">|</span> Time: <strong>${timeString}</strong> <span class="ticker-divider">|</span> Location: <strong>${userLocationText}</strong>`;
  });
}
