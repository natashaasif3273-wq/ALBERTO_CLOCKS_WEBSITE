/**
 * ==========================================================================
 * ALBERTO CLOCKS — PRODUCTS JAVASCRIPT (js/products.js)
 * Only loaded on products.html:
 *   1. Product Database Object
 *   2. Category Filtering with URL Parameter Support
 *   3. Product Details Modal Window
 * ==========================================================================
 */

const ALBERTO_PRODUCTS = {
  // Vintage Collection
  'vintage-1': {
    name: 'Alberto Heritage Chronometer 1952',
    category: 'Vintage',
    price: 'PKR 145,000',
    image: 'images/vintage/vintage-1.jpg',
    description: 'An homage to the mid-century golden age of Geneva horology. Features a hand-finished openworked balance wheel, silvered champagne patina dial, and hand-stitched navy alligator leather strap.',
    materials: 'Solid Stainless Steel & Hand-stitched Alligator Leather',
    movement: 'Calibre AC-1952 Manual Wind (48-Hour Power Reserve)',
    waterResistance: '50 Meters (5 ATM)',
    features: 'Breguet Blued Hands, Exhibition Sapphire Caseback, Anti-magnetic Hairspring'
  },
  'vintage-2': {
    name: 'Alberto 1952 Chronograph Master',
    category: 'Vintage',
    price: 'PKR 185,000',
    image: 'images/vintage/vintage-2.svg',
    description: 'Distinctive bi-compax chronograph with blued steel screws, certified chronometer grade escapement, and warm sunburst sub-dials.',
    materials: 'Brushed Silver Steel & Navy Calfskin Leather',
    movement: 'Calibre AC-V2 Column Wheel Mechanical',
    waterResistance: '30 Meters (3 ATM)',
    features: 'Tachymeter Scale, Dual Pushers, Domed Sapphire Crystal'
  },
  'vintage-3': {
    name: 'Alberto Royale Skeleton Pocket Clock',
    category: 'Vintage',
    price: 'PKR 220,000',
    image: 'images/gallery/gallery-2.svg',
    description: 'A stately antique pocket timepiece handcrafted with intricate filigree casing in polished silver, royal blue guilloche dial, and heavy silver chain.',
    materials: 'Solid Polished Silver with Silver Chain Included',
    movement: 'Hand-assembled Mechanical Calibre AC-88',
    waterResistance: 'Dust & Splash Resistant',
    features: 'Crown Bow Top Loop, Hinged Double Hunter Case, Roman Numeral Enamel Ring'
  },

  // Luxury Collection
  'luxury-1': {
    name: 'Alberto Tourbillon Royal Sapphire',
    category: 'Luxury',
    price: 'PKR 450,000',
    image: 'images/gallery/gallery-1.svg',
    description: 'The pinnacle of haute horlogerie. Features a 60-second flying tourbillon cage, midnight blue sapphire dial, pavé diamond bezel, and sculpted skeleton bridges in 904L steel.',
    materials: '904L Oystersteel, VVS Top Wesselton Diamonds, Solid Links',
    movement: 'Manufacture Calibre AC-900 Tourbillon Automatic',
    waterResistance: '50 Meters (5 ATM)',
    features: 'Flying Tourbillon, Diamond Hour Markers, Double AR-Coated Sapphire'
  },
  'luxury-2': {
    name: 'Alberto Grand Skeleton Silver Edition',
    category: 'Luxury',
    price: 'PKR 380,000',
    image: 'images/luxury/luxury-2.svg',
    description: 'Sculpted skeleton bridges plated in silver revealing the hypnotic oscillation of the balance wheel and ruby jewel bearings.',
    materials: 'Platinum-Plated 904L Stainless Steel',
    movement: 'Self-Winding In-house Calibre AC-650',
    waterResistance: '100 Meters (10 ATM)',
    features: '21 Synthetic Ruby Jewels, Skeleton Dial, Butterfly Deployment Clasp'
  },
  'luxury-3': {
    name: 'Alberto Celestial Moonphase Platinum',
    category: 'Luxury',
    price: 'PKR 320,000',
    image: 'images/gallery/gallery-3.svg',
    description: 'A midnight blue dial set with constellation starbursts and a polished silver moonphase disc that accurately tracks the lunar cycle.',
    materials: 'Solid Platinum & White Gold Bezel, Diamond Markers',
    movement: 'Astronomical Perpetual Moonphase Calibre AC-770',
    waterResistance: '50 Meters (5 ATM)',
    features: 'Astronomical Moon Disc, Diamond Indices, Midnight Sunburst Finish'
  },

  // Smart Watches
  'smart-1': {
    name: 'Alberto Horizon Smart Chrono',
    category: 'Smart Watches',
    price: 'PKR 85,000',
    image: 'images/smart/smart-1.jpg',
    description: 'Where Swiss luxury craftsmanship converges with cutting-edge digital intelligence. High-resolution AMOLED dial inside a sculpted silver-titanium case.',
    materials: 'Grade 5 Titanium with Sapphire Glass Bezel',
    movement: 'Alberto Cyber-Engine Quad-Core with 7-Day Battery',
    waterResistance: '50 Meters (5 ATM Swimming Proof)',
    features: 'Sapphire Touchscreen, ECG & Heart Rate, World Time, Bluetooth 5.3'
  },
  'smart-2': {
    name: 'Alberto Quantum Titanium Connect',
    category: 'Smart Watches',
    price: 'PKR 98,000',
    image: 'images/gallery/gallery-4.svg',
    description: 'A cushion-case luxury smartwatch featuring customizable haute horlogerie digital watch faces, sports telemetry, and silver crown navigation.',
    materials: 'Brushed Aerospace Titanium & Fluoroelastomer Strap',
    movement: 'Quantum Dual-Chipset Horology OS',
    waterResistance: '100 Meters (10 ATM)',
    features: 'Always-On Retina OLED, GPS Tracking, Rapid Wireless Charger'
  },
  'smart-3': {
    name: 'Alberto Cyber-Chrono Hybrid',
    category: 'Smart Watches',
    price: 'PKR 75,000',
    image: 'images/smart/smart-3.svg',
    description: 'The best of both worlds: physical silver luminescent mechanical hands over a hidden sub-OLED smart display screen.',
    materials: 'Stainless Steel Mesh Strap & Sapphire Crystal',
    movement: 'Hybrid Mechanical-Microprocessor Movement',
    waterResistance: '50 Meters (5 ATM)',
    features: 'Physical Silver Hands, Silent Vibration Alerts, 30-Day Battery Life'
  },

  // Classic Collection
  'classic-1': {
    name: 'Alberto Classique Enamel White',
    category: 'Classic',
    price: 'PKR 95,000',
    image: 'images/gallery/gallery-5.svg',
    description: 'Timeless understatement. Pure white porcelain enamel dial with silver applied Roman numerals and flame-blued leaf hands.',
    materials: 'Polished Silver Steel & Handcrafted Navy Leather',
    movement: 'Swiss High-Precision Quartz Calibre AC-10',
    waterResistance: '30 Meters (3 ATM)',
    features: 'Scratch-resistant Sapphire, Flame-blued Hands, Minimalist Crown'
  },
  'classic-2': {
    name: 'Alberto Geneva Roman Dial Automatic',
    category: 'Classic',
    price: 'PKR 130,000',
    image: 'images/classic/classic-2.svg',
    description: 'Guilloche engraved inner dial, crisp Roman markers, and a date complication window at the 3 o’clock position.',
    materials: 'Solid Stainless Steel with Polished Silver Bezel',
    movement: 'Automatic Calibre AC-2824 with 42-Hour Reserve',
    waterResistance: '50 Meters (5 ATM)',
    features: 'Guilloche Finish, Quickset Date, Transparent Exhibition Back'
  },
  'classic-3': {
    name: 'Alberto Ultra-Thin Milanese Silver',
    category: 'Classic',
    price: 'PKR 110,000',
    image: 'images/classic/classic-3.svg',
    description: 'Ultra-slim 6.2mm case profile with silver Milanese mesh bracelet. A modern tribute to clean, architectural elegance.',
    materials: 'Silver Milanese Stainless Steel Mesh',
    movement: 'Slimline High-Frequency Movement',
    waterResistance: '30 Meters (3 ATM)',
    features: '6.2mm Slim Case, Baton Markers, Magnetic Safety Clasp'
  },

  // Sports Watches
  'sports-1': {
    name: 'Alberto Seamaster Blue Chrono 300M',
    category: 'Sports Watches',
    price: 'PKR 210,000',
    image: 'images/sports/sports-1.jpg',
    description: 'Rugged luxury engineered for extreme depths. Solid 904L steel construction, unidirectional blue ceramic bezel, and water-resistance up to 300 meters.',
    materials: '904L Oystersteel Solid Links',
    movement: 'Alberto Marine Calibre 8800 Superlative Chronometer',
    waterResistance: '300 Meters (30 ATM Diving Grade)',
    features: 'Helium Escape Valve, Super-LumiNova Indices, Screw-down Crown'
  },
  'sports-2': {
    name: 'Alberto Oceanmaster 500M Diver',
    category: 'Sports Watches',
    price: 'PKR 245,000',
    image: 'images/gallery/gallery-6.svg',
    description: 'Professional deep-sea diving watch with ice-cyan luminescent markers, heavy-duty silver crown guards, and high-pressure sapphire.',
    materials: 'Stainless Steel Oyster Bracelet & Ceramic Blue Bezel',
    movement: 'Automatic Diving Calibre AC-500',
    waterResistance: '500 Meters (50 ATM)',
    features: 'Unidirectional 120-Click Bezel, Divers Extension Clasp'
  },
  'sports-3': {
    name: 'Alberto Daytona Speed Chronograph',
    category: 'Sports Watches',
    price: 'PKR 195,000',
    image: 'images/sports/sports-3.svg',
    description: 'Inspired by high-octane motorsport. Features a genuine carbon fiber dial, triple panda sub-dials, and tachymeter bezel calibrated to 400 km/h.',
    materials: 'Perforated Racing Calfskin & Brushed Silver Case',
    movement: 'High-Precision Flyback Chronograph Calibre AC-7750',
    waterResistance: '100 Meters (10 ATM)',
    features: 'Tachymeter Scale, Flyback Chronograph, Perforated Strap'
  }
};

document.addEventListener('DOMContentLoaded', () => {
  initProductFilter();
  initProductModal();
});

/* --------------------------------------------------------------------------
   1. PRODUCT FILTERING LOGIC
   -------------------------------------------------------------------------- */
function initProductFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card');

  if (filterBtns.length === 0 || productCards.length === 0) return;

  function filterCategory(targetCategory) {
    filterBtns.forEach(btn => {
      if (btn.getAttribute('data-filter') === targetCategory) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    productCards.forEach(card => {
      const cardCategory = card.getAttribute('data-category');
      if (targetCategory === 'all' || cardCategory === targetCategory) {
        card.style.display = 'flex';
      } else {
        card.style.display = 'none';
      }
    });
  }

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const selected = btn.getAttribute('data-filter');
      filterCategory(selected);
    });
  });

  const urlParams = new URLSearchParams(window.location.search);
  const paramCategory = urlParams.get('category');
  if (paramCategory) {
    filterCategory(paramCategory.toLowerCase());
  }
}

/* --------------------------------------------------------------------------
   2. PRODUCT DETAILS MODAL LOGIC
   -------------------------------------------------------------------------- */
function initProductModal() {
  const modal = document.getElementById('productModal');
  if (!modal) return;

  const closeBtn = document.getElementById('modalCloseBtn');
  const viewDetailBtns = document.querySelectorAll('.view-detail-btn');

  const modalImg = document.getElementById('modalImg');
  const modalCategory = document.getElementById('modalCategory');
  const modalTitle = document.getElementById('modalTitle');
  const modalPrice = document.getElementById('modalPrice');
  const modalDesc = document.getElementById('modalDesc');
  const modalMaterials = document.getElementById('modalMaterials');
  const modalMovement = document.getElementById('modalMovement');
  const modalWater = document.getElementById('modalWater');
  const modalFeatures = document.getElementById('modalFeatures');

  viewDetailBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const productId = btn.getAttribute('data-product-id');
      const product = ALBERTO_PRODUCTS[productId];

      if (product) {
        if (modalImg) { modalImg.src = product.image; modalImg.alt = product.name; }
        if (modalCategory) modalCategory.textContent = product.category;
        if (modalTitle) modalTitle.textContent = product.name;
        if (modalPrice) modalPrice.textContent = product.price;
        if (modalDesc) modalDesc.textContent = product.description;
        if (modalMaterials) modalMaterials.textContent = product.materials;
        if (modalMovement) modalMovement.textContent = product.movement;
        if (modalWater) modalWater.textContent = product.waterResistance;
        if (modalFeatures) modalFeatures.textContent = product.features;

        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  function closeModal() {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (closeBtn) closeBtn.addEventListener('click', closeModal);

  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('active')) {
      closeModal();
    }
  });
}
