/**
 * ==========================================================================
 * ALBERTO CLOCKS - ABOUT US PAGE JAVASCRIPT (js/about.js)
 * Dedicated scripts for about.html:
 *   - Atelier heritage milestones & brand story animations
 * ==========================================================================
 */

document.addEventListener("DOMContentLoaded", function () {

  console.log("Alberto Clocks Atelier Heritage (Est. 1988) Module Initialized.");

});
