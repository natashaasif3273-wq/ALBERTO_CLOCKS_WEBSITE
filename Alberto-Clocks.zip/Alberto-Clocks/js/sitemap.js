/**
 * ==========================================================================
 * ALBERTO CLOCKS - SITE MAP JAVASCRIPT (js/sitemap.js)
 * Dedicated scripts for sitemap.html:
 *   - Directory link navigation helpers
 * ==========================================================================
 */

document.addEventListener("DOMContentLoaded", function () {

  console.log("Alberto Clocks Site Map Directory Initialized: All 9 Pages Indexed.");

});
