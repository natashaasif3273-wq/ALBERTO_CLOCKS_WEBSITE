/**
 * ==========================================================================
 * ALBERTO CLOCKS - SCRIPT.JS
 * Description: Beginner-friendly vanilla JavaScript for ALBERTO CLOCKS website.
 * Features:
 *   1. Visitor Counter using localStorage (Increases by 1 each visit)
 *   2. Real-time Live Date and Time Updater
 *   3. HTML5 Geolocation API with Fallback ("Location unavailable")
 *   4. Product Category Filter (Vintage, Luxury, Smart, Classic, Sports)
 *   5. Product Details Modal Populator
 *   6. Gallery Image Modal Preview
 * ==========================================================================
 */

// Wait for the entire HTML document to load before running scripts
document.addEventListener("DOMContentLoaded", function () {
  
  // Initialize all features
  initVisitorCounter();
  initTickerDateTime();
  initGeolocation();
  initCategoryFilters();
  initProductDetailsModal();
  initGalleryModal();
  initContactForm();

});


/* ==========================================================================
   1. VISITOR COUNTER (USES localStorage)
   ========================================================================== */
function initVisitorCounter() {
  // Check if visitor counter element exists in the navbar
  const counterElement = document.getElementById("visitorCounterValue");
  if (!counterElement) return;

  // Retrieve current visit count from localStorage
  let count = localStorage.getItem("alberto_visitor_count");

  if (!count) {
    // If this is the very first visit, start with 1
    count = 1;
  } else {
    // Convert string count to number and increase by 1
    count = parseInt(count, 10) + 1;
  }

  // Save the updated count back to localStorage
  localStorage.setItem("alberto_visitor_count", count);

  // Format as 4 digits (e.g., 0001, 0025, 0124)
  const formattedCount = String(count).padStart(4, "0");

  // Display the count on the page
  counterElement.textContent = "Visitors: " + formattedCount;
}


/* ==========================================================================
   2. LIVE DATE & TIME IN BOTTOM TICKER
   ========================================================================== */
function initTickerDateTime() {
  const dateElements = document.querySelectorAll(".ticker-live-date");
  const timeElements = document.querySelectorAll(".ticker-live-time");

  // Function to update the date and time strings
  function updateDateTime() {
    const now = new Date();

    // Format Date: e.g. "Wednesday, Aug 26, 2026"
    const dateOptions = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
    const formattedDate = now.toLocaleDateString('en-US', dateOptions);

    // Format Time: e.g. "08:35:42 PM"
    const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
    const formattedTime = now.toLocaleTimeString('en-US', timeOptions);

    // Update all matching date ticker items
    dateElements.forEach(function (el) {
      el.textContent = formattedDate;
    });

    // Update all matching time ticker items
    timeElements.forEach(function (el) {
      el.textContent = formattedTime;
    });
  }

  // Update immediately upon page load
  updateDateTime();

  // Update every 1 second (1000 milliseconds)
  setInterval(updateDateTime, 1000);
}


/* ==========================================================================
   3. HTML5 GEOLOCATION API
   ========================================================================== */
function initGeolocation() {
  const locationElements = document.querySelectorAll(".ticker-live-location");
  if (locationElements.length === 0) return;

  // Set default message
  function setLocationText(text) {
    locationElements.forEach(function (el) {
      el.textContent = text;
    });
  }

  // Check if browser supports Geolocation API
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(
      // Success callback
      function (position) {
        const lat = position.coords.latitude.toFixed(2);
        const lon = position.coords.longitude.toFixed(2);
        const latDir = lat >= 0 ? "°N" : "°S";
        const lonDir = lon >= 0 ? "°E" : "°W";

        setLocationText(Math.abs(lat) + latDir + ", " + Math.abs(lon) + lonDir);
      },
      // Error or Permission Denied callback
      function (error) {
        // As requested in prompt: display "Location unavailable"
        setLocationText("Location unavailable");
      },
      // Options
      { timeout: 8000 }
    );
  } else {
    // Browser does not support geolocation
    setLocationText("Location unavailable");
  }
}


/* ==========================================================================
   4. PRODUCT CATEGORY FILTER (PRODUCTS PAGE)
   ========================================================================== */
function initCategoryFilters() {
  const filterButtons = document.querySelectorAll(".category-filter-wrap .filter-btn");
  const productCards = document.querySelectorAll(".product-item-col");

  if (filterButtons.length === 0 || productCards.length === 0) return;

  filterButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      // Remove 'active' class from all buttons
      filterButtons.forEach(function (b) { b.classList.remove("active"); });

      // Add 'active' class to clicked button
      this.classList.add("active");

      // Get selected category
      const selectedCategory = this.getAttribute("data-category");

      // Loop through all product cards and show/hide accordingly
      productCards.forEach(function (card) {
        const itemCategory = card.getAttribute("data-category");

        if (selectedCategory === "all" || selectedCategory === itemCategory) {
          card.style.display = "block";
          card.classList.add("fade-in");
        } else {
          card.style.display = "none";
        }
      });
    });
  });
}


/* ==========================================================================
   5. PRODUCT DETAILS MODAL POPULATOR
   ========================================================================== */
function initProductDetailsModal() {
  const detailButtons = document.querySelectorAll(".view-details-btn");
  const modalImage = document.getElementById("modalProductImage");
  const modalTitle = document.getElementById("modalProductTitle");
  const modalCategory = document.getElementById("modalProductCategory");
  const modalPrice = document.getElementById("modalProductPrice");
  const modalDesc = document.getElementById("modalProductDesc");
  const modalSpecs = document.getElementById("modalProductSpecs");

  if (detailButtons.length === 0 || !modalTitle) return;

  detailButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      // Read data attributes from clicked button
      const title = this.getAttribute("data-name") || "Alberto Clocks Timepiece";
      const category = this.getAttribute("data-category") || "Luxury";
      const price = this.getAttribute("data-price") || "$1,250";
      const desc = this.getAttribute("data-desc") || "Handcrafted with precision Swiss-inspired movement and sapphire glass.";
      const image = this.getAttribute("data-img") || "images/classic/classic-1.jpg";
      const specs = this.getAttribute("data-specs") || "Automatic Movement; 50m Water Resistance; Sapphire Crystal; 316L Stainless Steel";

      // Fill modal elements
      modalTitle.textContent = title;
      modalCategory.textContent = category;
      modalPrice.textContent = price;
      modalDesc.textContent = desc;
      modalImage.src = image;
      modalImage.alt = title;

      // Populate specifications list
      if (modalSpecs) {
        modalSpecs.innerHTML = "";
        const specItems = specs.split(";");
        specItems.forEach(function (spec) {
          if (spec.trim() !== "") {
            const li = document.createElement("li");
            const parts = spec.split(":");
            if (parts.length === 2) {
              li.innerHTML = '<span class="spec-label">' + parts[0].trim() + '</span><span>' + parts[1].trim() + '</span>';
            } else {
              li.innerHTML = '<span class="spec-label">Feature</span><span>' + spec.trim() + '</span>';
            }
            modalSpecs.appendChild(li);
          }
        });
      }
    });
  });
}


/* ==========================================================================
   6. GALLERY IMAGE MODAL PREVIEW
   ========================================================================== */
function initGalleryModal() {
  const galleryItems = document.querySelectorAll(".gallery-item");
  const modalImage = document.getElementById("galleryModalImage");
  const modalCaption = document.getElementById("galleryModalCaption");

  if (galleryItems.length === 0 || !modalImage) return;

  galleryItems.forEach(function (item) {
    item.addEventListener("click", function () {
      const img = this.querySelector("img");
      const caption = this.getAttribute("data-caption") || (img ? img.alt : "Alberto Clocks Timepiece");

      if (img) {
        modalImage.src = img.src;
        modalImage.alt = caption;
      }
      if (modalCaption) {
        modalCaption.textContent = caption;
      }
    });
  });
}


/* ==========================================================================
   7. CONTACT FORM SUBMISSION (USER FEEDBACK)
   ========================================================================== */
function initContactForm() {
  const contactForm = document.getElementById("albertoContactForm");
  const formSuccessAlert = document.getElementById("formSuccessAlert");

  if (!contactForm) return;

  contactForm.addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent default page refresh

    // Check basic form validity
    if (contactForm.checkValidity()) {
      if (formSuccessAlert) {
        formSuccessAlert.classList.remove("d-none");
      } else {
        alert("Thank you for contacting Alberto Clocks. Our concierge will be in touch with you shortly.");
      }
      contactForm.reset();
    }
  });
}
