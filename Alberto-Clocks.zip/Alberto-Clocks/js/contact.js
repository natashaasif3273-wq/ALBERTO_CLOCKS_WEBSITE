/**
 * ==========================================================================
 * ALBERTO CLOCKS - CONTACT US JAVASCRIPT (js/contact.js)
 * Dedicated scripts for contact.html:
 *   - Client inquiry form validation
 *   - Submission event interception and instant confirmation feedback
 * ==========================================================================
 */

document.addEventListener("DOMContentLoaded", function () {

  initContactForm();

});

function initContactForm() {
  const form = document.getElementById("albertoContactForm");
  const alertBox = document.getElementById("formSuccessAlert");

  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent standard browser page reload

    if (form.checkValidity()) {
      if (alertBox) {
        alertBox.classList.remove("d-none");
        alertBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
      } else {
        alert("Thank you for contacting Alberto Clocks. Our concierge desk will respond within 24 hours.");
      }
      form.reset();
    } else {
      form.reportValidity();
    }
  });
}
