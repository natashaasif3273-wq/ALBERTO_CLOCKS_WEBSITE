/**
 * ==========================================================================
 * ALBERTO CLOCKS — STORE LOCATOR JAVASCRIPT (js/store.js)
 * Only loaded on store.html / store-locator.html: Real-time Boutique Search
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  initStoreSearch();
});

function initStoreSearch() {
  const searchInput = document.getElementById('storeSearchInput');
  const storeCards = document.querySelectorAll('.store-card');
  const noResultsNotice = document.getElementById('noStoreResults');

  if (!searchInput || storeCards.length === 0) return;

  searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase().trim();
    let visibleCount = 0;

    storeCards.forEach(card => {
      const text = card.textContent.toLowerCase();
      if (text.includes(query)) {
        card.style.display = 'block';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });

    if (noResultsNotice) {
      noResultsNotice.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  });
}
